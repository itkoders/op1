# IT Coders APK — GitHub Actions orqali

Bu loyiha `https://itcoders-op1-site.onrender.com` saytini Android WebView ichida ochadi. GitHub Actions workflow debug APK yig‘ib, artifact sifatida saqlaydi.

## Repozitoriyga qo‘shish
ZIP ichidagi `.github` va `android` papkalarini `itkoders/op1` repozitoriyasining `main` branchiga yuklang. Mavjud `index.html` faylini o‘chirmang yoki almashtirmang.

## APK yig‘ish
1. GitHub’da `itkoders/op1` repozitoriyasini oching.
2. Actions bo‘limiga kiring.
3. `Build IT Coders APK` workflow’ini tanlang.
4. `Run workflow` tugmasini bosing.
5. Ish tugab yashil bo‘lsa, bajarilgan workflow run’ini oching.
6. `Artifacts` ostidan `IT-Coders-debug-APK` ZIP faylini yuklab oling.
7. ZIP’ni ochib `app-debug.apk` faylini telefonga o‘rnating.

## Muhim
- Bu debug APK; Play Store uchun release-signing alohida kerak.
- Ilova saytni internet orqali ochadi. Sayt yoki uning funksiyalari ishlamasa, APK ichida ham ishlamasligi mumkin.
- APK yig‘ilishi hali bajarilmagan va testdan o‘tgan deb hisoblanmaydi.
