# IT Coders Android ilovasi

Bu loyiha mavjud IT Coders saytini Android WebView ilovasi ichida ochadi.

## Muhim
- Bu hozircha APK emas, APK yig‘ish uchun Android Studio/Android SDK talab qiladigan manba loyiha.
- Ilova internetga ulangan holda `https://itcoders-op1-site.onrender.com` saytini yuklaydi.
- Sayt ichidagi AI xizmatlari uchun tegishli API kalitlari talab qilinishi mumkin.
- Bu loyiha APK yig‘ilgach haqiqiy telefonda tekshirilishi kerak.

## APK yig‘ish (kompyuterda Android Studio)
1. ZIP faylni oching.
2. Android Studio → Open → `ITCoders-Android` papkasini tanlang.
3. Gradle sync tugashini kuting.
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
5. `app/build/outputs/apk/debug/app-debug.apk` faylini telefonga ko‘chiring va o‘rnating.

## Android telefonda
AndroidIDE kabi Android SDK va Gradle qo‘llaydigan IDE orqali loyihani ochib yig‘ish mumkin. Ilova o‘rnatilishidan oldin qurilma xavfsizlik sozlamalarida shu manbadan o‘rnatishga ruxsat talab qilinishi mumkin.

## Ilova tafsilotlari
- Ilova nomi: IT Coders
- Package ID: `uz.itcoders.app`
- Minimal Android: 6.0 (API 23)
