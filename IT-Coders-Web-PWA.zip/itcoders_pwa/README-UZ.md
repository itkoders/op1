# IT Coders Corporation — Web + PWA package

## Nimalar bor
- `index.html` — yuklangan HTML loyihangiz, PWA o‘rnatish metama’lumotlari qo‘shilgan.
- `manifest.webmanifest` — ilova nomi va ikonkalari.
- `sw.js` — birinchi yuklangandan keyin asosiy sahifani oflayn ochishga yordam beruvchi service worker.
- `icons/` — 192 va 512 px ikonka.

## Render’da bepul statik sayt qilish (telefon orqali)
1. ZIP’ni oching. Fayllar bitta papkada tursin: `index.html`, `manifest.webmanifest`, `sw.js`, `icons/`.
2. Papkani GitHub repository’ga yuklang (brauzer orqali Add file → Upload files).
3. Render’da **New + → Static Site** tanlang va shu repository’ni ulang.
4. Build Command bo‘sh; Publish Directory `.`; so‘ng Deploy. Docker service tanlamang — bu paketga Dockerfile kerak emas.
5. HTTPS manzil ochilgach, Chrome’da saytni oching. Menyu → **Install app / Add to Home screen**.

## Android APK
PWA sayt HTTPS’da ishlagach, telefondan `https://www.pwabuilder.com/` saytini ochib, ommaviy sayt manzilini kiriting va Android package yaratish yo‘riqnomasini bajaring. APK yaratish tashqi xizmat orqali amalga oshadi; bu ZIP’ning o‘zi APK emas.

## Muhim cheklovlar va xavfsizlik
- HTML ichidagi interfeys va brauzer funksiyalari saqlangan, ammo bu statik paket barcha integratsiyalar ishlashini kafolatlamaydi. AI API kalitlari va Telegram bot tokenini brauzerga kiritish xavfli: ular qurilmada ko‘rinishi mumkin. Haqiqiy, doimiy Telegram bot va maxfiy AI kalitlari uchun alohida server/backend kerak.
- Telegram polling va API chaqiruvlari brauzer yopilganda to‘xtashi mumkin. PWA ichidagi bot serverda 24/7 ishlaydigan bot bilan bir xil emas.
- Tekshiruv: JavaScript sintaksisi Node.js `--check` orqali tekshirildi. To‘liq brauzerda/Render’da runtime sinovi ushbu muhitda bajarilmadi.
